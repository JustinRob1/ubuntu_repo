[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/d5v4UTW1)
# Labsignment: django-npm

* Name: Justin Robertson
* CCID: jtrober1
* eMail: jtrober1@ualberta.ca
* Student ID: 1702786

Assignment instructions [are on the website](https://uofa-cmput404.github.io/labsignments/django.html).

Don't forget to submit a link to this repo on your eClass.

## Write down any collaboration or citations that aren't in the code here:

* [https://docs.djangoproject.com/en/5.1/](https://docs.djangoproject.com/en/5.1/)
* [https://docs.djangoproject.com/en/5.1/intro/tutorial01/](https://docs.djangoproject.com/en/5.1/intro/tutorial01/)
* [https://github.com/UAlberta-CMPUT401-Wi2024/api-assignment-JustinRob1](https://github.com/UAlberta-CMPUT401-Wi2024/api-assignment-JustinRob1) My CMPUT 401 API assignment. I think the repo is private however.
* 