from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.utils import timezone

from .models import Page, Like

# Create your views here.
def index(request):
    pages = []

    page_objects = Page.objects.all()
    for page in page_objects:
        pages.append({
            "title": page.title,
            "url": reverse("view", kwargs={ "id": page.id })
        })
    return render(request, "index.html", { "pages": pages })

def view_page(request, id):
    page = get_object_or_404(Page, pk=id)
    return render(request, "page.html", { "title": page.title, "content": page.content, "like_count": page.like_count, "id": id })

def editor(request):
    return render(request, "editor.html")

# From https://docs.djangoproject.com/en/5.1/topics/forms/, by Django Software Foundation, Downloaded 2024-09-22
def save(request):
    if request.method == "POST":
        # If the request is a POST, a new Page object is created using the data submitted in the form (from editor.html)
        wiki = Page(title=request.POST["title"], content=request.POST["content"])
        # Page object is saved to the database
        wiki.save()
        # Redirects the user to the index page ("index" comes from the name in urls.py)
        return HttpResponseRedirect(reverse("index"))

# The following function from Microsoft, Copilot, "How can I store the number of page likes including
# when each page was liked?", 2024-09-22
def like_page(request, id):
    if request.method == "POST":
        # Retrieves the page object with the provided id, 404 is raised if the id does not exist
        page = get_object_or_404(Page, pk=id)
        page.like_count += 1
        page.save()
        # Create a new like object that is associated with the Page object
        like = Like(page=page)
        like.save()
        # Redirects the user to the view page ("view" comes from the name in urls.py)
        # Need to pass the id of the Page since the path requires it
        return HttpResponseRedirect(reverse("view", kwargs={ "id": id }))

# The following function from Microsoft, Copilot, "How can I display a list of the likes for a specific wiki page
# including when each page was liked?", 2024-09-22
# From https://docs.djangoproject.com/en/5.1/topics/i18n/timezones/, by Django Software Foundation, Downloaded 2024-09-22
def view_likes(request, id):
    # Retrieves the page object with the provided id, 404 is raised if the id does not exist
    page = get_object_or_404(Page, pk=id)
    # Retrieves all of the likes associated with the page object
    likes = page.likes.all()
    # Iterates through each like object and stores the created_at attribute in a list
    like_dates = [timezone.localtime(like.created_at).strftime("%Y-%m-%d %H:%M:%S") for like in likes]
    context = {
        "id": page.id,
        "title": page.title,
        "likes": like_dates
    }
    # Renders the likes.html page, passing the context data to display the lukes
    return render(request, "likes.html", context)