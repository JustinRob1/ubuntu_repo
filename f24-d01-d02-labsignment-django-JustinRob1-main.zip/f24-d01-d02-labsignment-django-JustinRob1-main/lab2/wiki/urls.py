from django.urls import path
from . import views

# When users visit the URL, views.`function` will be called, which is defined in views.py
# name= refers to the name of the path which can be used in other parts of the project
urlpatterns = [
    path("", views.index, name="index"),
    path("add/", views.editor, name="add"),
    path("save/", views.save, name="save"),
    path("page/<int:id>/", views.view_page, name="view"),
    path("page/<int:id>/like/", views.like_page, name="like_page"),
    path("page/<int:id>/likes/", views.view_likes, name="view_likes"),
]
