from django.db import models

# Create your models here.
class Page(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=200)
    content = models.TextField()  # Markdown content
    created_at = models.DateTimeField(auto_now_add=True)
    like_count = models.IntegerField(default=0)

    def __str__(self):
        return f"#{self.id} - {self.title}"
    
# From https://docs.djangoproject.com/en/5.1/ref/models/fields/, by Django Software Foundation, Downloaded 2024-09-22
# From https://docs.djangoproject.com/en/5.1/topics/db/examples/many_to_one/, by Django Software Foundation, Downloaded 2024-09-22
# From https://sentry.io/answers/what-is-related-name-used-for/, by Gareth D, Downloaded 2024-09-22
# Used for ForeignKey class and related_name attribute

# Repersents a like on each page.
# models.Foregin creates a many-to-one relationship, each like is associated with one page but a page
# can have many likes.
# on_delete=models.CASCADE means that if the page is deleted the all likes for that page will also be deleted.
# related_name='likes' allous acces to all Like instances related to a Page using page.likes
class Like(models.Model):
    page = models.ForeignKey(Page, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"#{self.page.id} - {self.created_at}"