from django.contrib import admin

from .models import Page, Like

# Register your models here.

admin.site.register(Page)
admin.site.register(Like)